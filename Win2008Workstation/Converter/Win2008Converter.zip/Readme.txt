Windows Server 2008 Workstation Converter version 1.0 by sawo
A utility that allows you to turn Windows Server 2008 into a very powerful workstation!

WARNING: THIS PROGRAM REQUIRES ATLEAST .NET FRAMEWORK 2.0 (no need to install on server 2008)!
IF YOU RECEIVE ERROR WHEN RUNNING IT, SIMPLY TYPE THIS IN RUN OR CMD: ServerManagerCmd -install NET-Framework-Core
NO REBOOT IS REQUIRED!

LICENSE:
You can do whatever you want with this application as long as you give me credit!

****
Thanks to everyone who helped me with the testing, the tweaks and everything else!
****

Features supported so far:
1. Set owner name/organization
2. Enable windows audio
3. Optimize CPU performance for programs
4. Disable IE Enhanced Security Configuration
5. Install .NET Framework 3.0
6. Enable SuperFetch
7. Install desktop experience
8. Enable themes
9. Disable CTRL+ALT+DEL at Startup
10. Disable shutdown event tracker
11. Change computer name
12. Enable wireless networking
13. Enable offline files
14. Enable windows search service
15. Enable auto logon
16. Delay activation
17. UxTheme patch for x86 and x64 systems
18. Disable verbose messages at startup/shutdown
19. Install the vista aero cursors
20. Install the vista sidebar (x86 and x64)
21. Install the control panel item for game controllers(x86 and x64)
22. Enable Speech Recognition (require files from vista)
*Many of the tweaks require Admin account to apply so make sure you run the program as administrator.

Most of the tweaks are available using command line/shortcut parameter:
-audio      Enable windows audio
-cpu        Optimize CPU performance for programs
-ie         Disable IE Enhanced Security Configuration
-dotnet     Install .NET Framework 3.0
-superfetch Enable SuperFetch
-desktop    Install desktop experience
-themes     Enable themes
-cad        Disable CTRL+ALT+DEL at Startup
-events     Disable shutdown event tracker
-name       Change computer name
-wireless   Enable wireless networking
-offline    Enable offline files
-search     Enable windows search service
-autologin  Enable auto logon
-delay      Delay activation
-check      Check the remaining days left until activation
-uxtheme32  Apply the UxTheme Patch for 32bit systems
-uxtheme64  Apply the UxTheme Patch for 64bit systems
-sidebar32  Install the sidebar for 32bit systems.
-sidebar64  Install the sidebar for 64bit systems.
-joy32      Install the control panel item for game controllers on 32bit systems.
-joy64      Install the control panel item for game controllers on 64bit systems.
-cursors    Install the vista aero cursors.

Note that i do not work for microsoft - i created this program in my spare time so i cannot provide support
or patches for it. I will try to help the users and improve the program in the future, but i do not guaranteee
anything - USE IT AT OWN RISK!
If you want to contact me, mail me at sawo.777@gmail.com